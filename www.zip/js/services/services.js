angular.module('clout.services', [])

.factory('Chats', function() {
  
});
